import sys
from os.path import dirname, join, realpath

project_dirname = dirname(dirname(realpath(__file__)))
path = join(project_dirname, "bank2ynab")

if path not in sys.path:
    sys.path.append(path)
