# commented out pending test rework
'''
from copy import copy
from unittest import TestCase

from os.path import join, abspath, exists

import os

from bank2ynab.bank_process import B2YBank, build_bank
from bank2ynab.b2y_utilities import fix_conf_params
from bank2ynab.plugins.null import NullBank
from test.utils import get_test_confparser, get_project_dir


class TestB2YBank(TestCase):

    TESTCONFPATH = join("test-data", "test.conf")

    def setUp(self):
        self.cp = get_test_confparser()
        self.defaults = dict(self.cp.defaults())
        self.b = None
        self.test_data = join(get_project_dir(), "test-data")

    def tearDown(self):
        pass













    """
'''
