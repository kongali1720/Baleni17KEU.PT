# Bank2YNAB Privacy Policy

This one is going to be easy:

- We don't have access to your data. Full stop. "We" meaning the developers of `bank2ynab` as listed on the GitHub contributors page: https://github.com/bank2ynab/bank2ynab/graphs/contributors
- Your financial information, YNAB data, and YNAB access token is kept strictly between your computer and YNAB.
- We don't store any data on any servers - we don't have any servers!
- No, really, we cannot and do not access or store your data - it's all yours! Your data is sent only to YNAB and nowhere else.

Any concerns or inquiries may be directed to the contributors as a new ticket: https://github.com/bank2ynab/bank2ynab/issues/new/choose
