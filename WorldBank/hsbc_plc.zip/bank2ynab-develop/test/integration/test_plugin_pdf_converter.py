import unittest
from unittest import TestCase


class TestDataframeHandler(TestCase):
    def setUp(self) -> None:
        return super().setUp()

    def tearDown(self) -> None:
        return super().tearDown()

    @unittest.skip("Not tested yet.")
    def test_pdf_converter_class(self):
        raise NotImplementedError

    @unittest.skip("Not tested yet.")
    def test_preprocess_file(self):
        raise NotImplementedError

    @unittest.skip("Not tested yet.")
    def test_read_pdf_to_dataframe(self):
        raise NotImplementedError
